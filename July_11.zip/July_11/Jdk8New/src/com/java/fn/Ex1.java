package com.java.fn;

import java.util.Arrays;
import java.util.List;

public class Ex1 {
	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(50,66,23,63,0,65);
		numbers.forEach(x-> System.out.println(50/x));
	}
}
