
public class Prog1 {

	public static void main(String[] args) {
		int age = 18;
		if (age >= 18) {
			System.out.println("You can vote..");
		} else {
			System.out.println("You Cannot Vote...");
		}
	}
}
