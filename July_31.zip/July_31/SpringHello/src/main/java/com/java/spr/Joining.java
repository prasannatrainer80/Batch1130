package com.java.spr;

public interface Joining {

	void show(String name);
}
