package com.java.spr;

public interface Visitor {

	void showAmbiance(String visitor);
}
