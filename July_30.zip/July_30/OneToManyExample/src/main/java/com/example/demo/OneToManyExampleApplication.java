package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToManyExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToManyExampleApplication.class, args);
	}

}
