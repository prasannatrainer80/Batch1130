package com.java.junit;

import org.junit.Test;

public class AppTest {

  
}
