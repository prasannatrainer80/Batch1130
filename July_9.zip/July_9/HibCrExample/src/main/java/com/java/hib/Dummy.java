package com.java.hib;

public class Dummy {
	public static void main(String[] args) {
		System.out.println(EncryptPassword.getCode("Sekhar"));
	}
}
