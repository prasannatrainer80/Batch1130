package com.java.spr;

public interface Feedback {

	String fbInfo();
}
